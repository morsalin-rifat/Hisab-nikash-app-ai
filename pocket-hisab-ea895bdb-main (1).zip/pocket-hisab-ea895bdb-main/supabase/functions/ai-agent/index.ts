import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `তুমি "পকেট হিসাব" অ্যাপের AI এসিস্ট্যান্ট। তোমার নাম "হিসাব AI"। তুমি বাংলা, ইংরেজি এবং বাংলিশ বুঝতে পারো।

তুমি যা করতে পারো:
1. আর্থিক পরামর্শ দিতে পারো (কীভাবে সেভ করবে, বাজেট করবে)
2. অ্যাপের ফিচার সম্পর্কে গাইড করতে পারো
3. খরচের প্যাটার্ন বিশ্লেষণ করতে পারো
4. সেভিংস টিপস দিতে পারো
5. বাংলাদেশের আর্থিক বিষয়ে সাহায্য করতে পারো

গুরুত্বপূর্ণ নিয়ম:
- সবসময় বাংলায় উত্তর দাও (যদি না ইংরেজিতে জিজ্ঞাসা করা হয়)
- সংক্ষেপে ও সহজ ভাষায় বলো
- ইমোজি ব্যবহার করো তবে বেশি না
- ব্যবহারকারীকে সেভ করতে ও বাজেটে থাকতে উৎসাহিত করো
- লেনদেন যোগ করতে চাইলে বলো "✨ বোতাম ব্যবহার করুন বা ট্রান্সাকশন মোডে লিখুন"`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Credits exhausted" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      throw new Error("AI gateway error");
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-agent error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
