import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { message } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are a Bengali finance assistant for "Pocket Hisab" app. Parse user input (Bangla, English, or Banglish with typos) into a structured transaction.

RULES:
- Detect transaction type: "expense", "income", or "transfer"
- Extract amount (number only)
- Detect category from these options:
  Expense: খাবার, যাতায়াত, শপিং, বিল, স্বাস্থ্য, শিক্ষা, বিনোদন, পরিবার, অন্যান্য
  Income: বেতন, ফ্রিল্যান্স, ব্যবসা, উপহার, বিনিয়োগ, অন্যান্য
- Detect wallet preference: Cash, bKash, Bank (default: Cash)
- Extract any note from context
- For transfer: detect from_wallet and to_wallet
- Handle Banglish like "khabar", "bikas", "beton" etc.
- Handle typos gracefully

Always respond using the suggest_transaction tool.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "suggest_transaction",
              description: "Suggest a parsed transaction from natural language input",
              parameters: {
                type: "object",
                properties: {
                  type: { type: "string", enum: ["expense", "income", "transfer"] },
                  amount: { type: "number" },
                  category: { type: "string" },
                  wallet: { type: "string", enum: ["Cash", "bKash", "Bank"] },
                  to_wallet: { type: "string", enum: ["Cash", "bKash", "Bank"] },
                  note: { type: "string" },
                  confidence: { type: "number", description: "0-1 confidence score" },
                  display_summary: { type: "string", description: "Bengali summary of what was parsed" },
                },
                required: ["type", "amount", "category", "wallet", "confidence", "display_summary"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "suggest_transaction" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI ক্রেডিট শেষ হয়ে গেছে।" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    
    if (toolCall?.function?.arguments) {
      const parsed = JSON.parse(toolCall.function.arguments);
      return new Response(JSON.stringify(parsed), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    throw new Error("No tool call response");
  } catch (e) {
    console.error("parse-transaction error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
