import { motion } from "framer-motion";
import { useWallets } from "@/hooks/useWallets";
import { Skeleton } from "@/components/ui/skeleton";
import { Banknote, Smartphone, Building2, Plus } from "lucide-react";

const walletIcons: Record<string, any> = {
  cash: Banknote,
  mobile_banking: Smartphone,
  bank: Building2,
};

const walletGradients: Record<string, string> = {
  cash: "from-success/20 to-success/5",
  mobile_banking: "from-neon-pink/20 to-neon-pink/5",
  bank: "from-primary/20 to-primary/5",
};

const WalletStacks = () => {
  const { data: wallets, isLoading } = useWallets();

  if (isLoading) {
    return (
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-20 w-32 rounded-2xl shrink-0" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex gap-2.5 overflow-x-auto scrollbar-hide pb-1">
      {wallets?.map((wallet, i) => {
        const Icon = walletIcons[wallet.type] || Building2;
        const gradient = walletGradients[wallet.type] || "from-muted to-muted/50";
        return (
          <motion.div
            key={wallet.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.08 }}
            className={`glass-card rounded-2xl p-3.5 min-w-[120px] shrink-0 bg-gradient-to-br ${gradient}`}
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
          >
            <Icon className="w-4 h-4 text-muted-foreground mb-2" />
            <p className="text-base font-bold font-mono text-foreground leading-none">
              ৳{wallet.balance.toLocaleString("bn-BD")}
            </p>
            <p className="text-[11px] text-muted-foreground mt-1 font-medium">{wallet.name}</p>
          </motion.div>
        );
      })}
    </div>
  );
};

export default WalletStacks;
