import { motion } from "framer-motion";
import { useState } from "react";
import { Wallet, CreditCard, Smartphone } from "lucide-react";
import type { Wallet as WalletType } from "@/hooks/useWallets";

interface WalletCardProps {
  wallet: WalletType;
  index: number;
}

const walletIcons: Record<string, React.ElementType> = {
  cash: Wallet,
  bank: CreditCard,
  mobile_banking: Smartphone,
};

const walletGradients: Record<string, string> = {
  cash: "from-emerald-500/20 to-emerald-700/10",
  bank: "from-blue-500/20 to-blue-700/10",
  mobile_banking: "from-pink-500/20 to-pink-700/10",
};

const WalletCard = ({ wallet, index }: WalletCardProps) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const Icon = walletIcons[wallet.type] || Wallet;
  const gradient = walletGradients[wallet.type] || walletGradients.cash;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="cursor-pointer min-w-0"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className={`glass-card rounded-xl p-3 bg-gradient-to-br ${gradient} transition-shadow`}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.5 }}
        style={{ transformStyle: "preserve-3d" }}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
      >
        <div style={{ backfaceVisibility: "hidden" }} className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-background/50 flex items-center justify-center shrink-0">
            <Icon className="w-3.5 h-3.5 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] text-muted-foreground truncate">{wallet.name}</p>
            <p className="text-sm font-bold text-foreground font-mono">
              ৳{wallet.balance.toLocaleString("bn-BD")}
            </p>
          </div>
        </div>

        <div
          className="absolute inset-0 flex flex-col items-center justify-center p-3 rounded-xl"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <Icon className="w-5 h-5 text-primary mb-1" />
          <p className="text-xs font-medium text-foreground">{wallet.name}</p>
          <p className="text-base font-bold font-mono text-foreground">
            ৳{wallet.balance.toLocaleString("bn-BD")}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default WalletCard;
