import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Target, Plus, ChevronRight, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { triggerHaptic } from "@/lib/haptics";

const goalIcons = ["🎯", "🏠", "🚗", "📱", "💻", "✈️", "📚", "💍", "🎓", "💰"];

const SavingsGoals = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [addSheetOpen, setAddSheetOpen] = useState(false);
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const [selectedIcon, setSelectedIcon] = useState("🎯");
  const [addAmount, setAddAmount] = useState("");
  const [activeGoalId, setActiveGoalId] = useState<string | null>(null);

  const { data: goals = [] } = useQuery({
    queryKey: ["savings_goals", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("savings_goals")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const handleCreate = async () => {
    if (!user || !name || !target) return;
    const { error } = await supabase.from("savings_goals").insert({
      user_id: user.id,
      name: name.trim(),
      target_amount: Number(target),
      icon: selectedIcon,
    });
    if (error) { toast.error(error.message); return; }
    triggerHaptic("medium");
    toast.success("সেভিংস গোল তৈরি হয়েছে! 🎯");
    queryClient.invalidateQueries({ queryKey: ["savings_goals"] });
    setName(""); setTarget(""); setSheetOpen(false);
  };

  const handleAddSavings = async () => {
    if (!activeGoalId || !addAmount) return;
    const goal = goals.find((g: any) => g.id === activeGoalId);
    if (!goal) return;
    const newAmount = (goal as any).saved_amount + Number(addAmount);
    const isCompleted = newAmount >= (goal as any).target_amount;
    await supabase.from("savings_goals").update({
      saved_amount: newAmount,
      is_completed: isCompleted,
    }).eq("id", activeGoalId);
    triggerHaptic("medium");
    toast.success(isCompleted ? "গোল সম্পন্ন! 🎉" : `৳${Number(addAmount).toLocaleString("bn-BD")} যোগ হয়েছে!`);
    queryClient.invalidateQueries({ queryKey: ["savings_goals"] });
    setAddAmount(""); setAddSheetOpen(false);
  };

  const handleDelete = async (id: string) => {
    await supabase.from("savings_goals").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["savings_goals"] });
    toast.success("গোল ডিলিট হয়েছে");
  };

  const activeGoals = goals.filter((g: any) => !(g as any).is_completed);
  const topGoal = activeGoals[0] as any;

  return (
    <>
      {/* Compact Card on Dashboard */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="glass-card rounded-2xl p-3.5"
      >
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">সেভিংস</h3>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setSheetOpen(true)}>
            <Plus className="w-3.5 h-3.5" />
          </Button>
        </div>

        {topGoal ? (
          <div
            className="cursor-pointer"
            onClick={() => { setActiveGoalId(topGoal.id); setAddSheetOpen(true); }}
          >
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-lg">{topGoal.icon}</span>
              <span className="text-xs font-medium text-foreground truncate">{topGoal.name}</span>
            </div>
            <Progress
              value={topGoal.target_amount > 0 ? (topGoal.saved_amount / topGoal.target_amount) * 100 : 0}
              className="h-1.5 mb-1"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>৳{topGoal.saved_amount.toLocaleString("bn-BD")}</span>
              <span>৳{topGoal.target_amount.toLocaleString("bn-BD")}</span>
            </div>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center py-2">কোনো গোল নেই</p>
        )}

        {activeGoals.length > 1 && (
          <p className="text-[10px] text-primary text-center mt-2 font-medium">
            +{activeGoals.length - 1} আরো গোল
          </p>
        )}
      </motion.div>

      {/* Create Goal Sheet */}
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent side="bottom" className="bg-background border-t border-border rounded-t-3xl">
          <SheetHeader><SheetTitle className="text-foreground">নতুন সেভিংস গোল</SheetTitle></SheetHeader>
          <div className="space-y-4 mt-4">
            <div className="flex gap-2 flex-wrap">
              {goalIcons.map(icon => (
                <button
                  key={icon}
                  onClick={() => setSelectedIcon(icon)}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-all ${
                    selectedIcon === icon ? "bg-primary/20 border border-primary/30 scale-110" : "bg-muted/50"
                  }`}
                >
                  {icon}
                </button>
              ))}
            </div>
            <Input placeholder="গোলের নাম (যেমন: নতুন ফোন)" value={name} onChange={e => setName(e.target.value)}
              className="rounded-xl bg-muted/50 border-border" />
            <Input type="number" placeholder="টার্গেট পরিমাণ (৳)" value={target} onChange={e => setTarget(e.target.value)}
              className="rounded-xl bg-muted/50 border-border font-mono" />
            <Button onClick={handleCreate} disabled={!name || !target} className="w-full py-5 rounded-xl">
              তৈরি করুন
            </Button>
          </div>

          {/* Existing Goals List */}
          {goals.length > 0 && (
            <div className="mt-6 space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground">সকল গোল</h4>
              {goals.map((g: any) => {
                const pct = g.target_amount > 0 ? (g.saved_amount / g.target_amount) * 100 : 0;
                return (
                  <div key={g.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-muted/30">
                    <span className="text-lg">{g.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{g.name}</p>
                      <Progress value={pct} className="h-1 mt-1" />
                    </div>
                    <span className="text-[10px] font-mono text-muted-foreground">{Math.round(pct)}%</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive"
                      onClick={() => handleDelete(g.id)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Add Savings Sheet */}
      <Sheet open={addSheetOpen} onOpenChange={setAddSheetOpen}>
        <SheetContent side="bottom" className="bg-background border-t border-border rounded-t-3xl">
          <SheetHeader><SheetTitle className="text-foreground">সেভিংসে যোগ করুন</SheetTitle></SheetHeader>
          <div className="space-y-4 mt-4">
            <Input type="number" placeholder="পরিমাণ (৳)" value={addAmount} onChange={e => setAddAmount(e.target.value)}
              className="rounded-xl bg-muted/50 border-border font-mono text-2xl text-center h-16" />
            <Button onClick={handleAddSavings} disabled={!addAmount || Number(addAmount) <= 0} className="w-full py-5 rounded-xl">
              যোগ করুন
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
};

export default SavingsGoals;
