import { motion } from "framer-motion";
import { Home, PieChart, Plus, Wallet, Settings } from "lucide-react";

interface BottomNavProps {
  onAddClick: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: "home", icon: Home, label: "হোম" },
  { id: "stats", icon: PieChart, label: "পরিসংখ্যান" },
  { id: "add", icon: Plus, label: "যোগ" },
  { id: "wallets", icon: Wallet, label: "ইভেন্ট" },
  { id: "settings", icon: Settings, label: "সেটিংস" },
];

const BottomNav = ({ onAddClick, activeTab, onTabChange }: BottomNavProps) => {
  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-40"
    >
      <div className="max-w-lg mx-auto">
        <div className="glass-card border-t border-border/50 px-2 py-2.5 flex items-center justify-around">
          {tabs.map((tab) => {
            const isAdd = tab.id === "add";
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;

            if (isAdd) {
              return (
                <motion.button
                  key={tab.id}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onAddClick}
                  className="w-13 h-13 rounded-2xl bg-gradient-to-br from-primary to-accent text-primary-foreground flex items-center justify-center -mt-7 shadow-lg shadow-primary/30"
                >
                  <Plus className="w-6 h-6" />
                </motion.button>
              );
            }

            return (
              <motion.button
                key={tab.id}
                whileTap={{ scale: 0.9 }}
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-semibold">{tab.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="w-1.5 h-1.5 rounded-full bg-primary"
                  />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </motion.nav>
  );
};

export default BottomNav;
