import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Bell, X } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const DashboardHeader = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [showNotifs, setShowNotifs] = useState(false);

  const displayName =
    user?.user_metadata?.full_name ||
    user?.email?.split("@")[0] ||
    "ব্যবহারকারী";

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "সুপ্রভাত" : hour < 17 ? "শুভ অপরাহ্ণ" : "শুভ সন্ধ্যা";
  const emoji = hour < 12 ? "🌅" : hour < 17 ? "☀️" : "🌙";

  const { data: notifications = [] } = useQuery({
    queryKey: ["notifications", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);
      return data || [];
    },
    enabled: !!user,
  });

  const unreadCount = notifications.filter((n: any) => !n.is_read).length;

  const markAllRead = async () => {
    if (!user) return;
    await supabase
      .from("notifications")
      .update({ is_read: true })
      .eq("user_id", user.id)
      .eq("is_read", false);
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
  };

  return (
    <>
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between mb-5"
      >
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border border-primary/20">
            <span className="text-xl">{emoji}</span>
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">{greeting}</p>
            <h1 className="text-lg font-bold text-foreground leading-tight tracking-tight">
              {displayName}
            </h1>
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="relative text-muted-foreground hover:text-foreground rounded-xl"
          onClick={() => { setShowNotifs(!showNotifs); if (!showNotifs) markAllRead(); }}
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-destructive text-destructive-foreground text-[9px] font-bold flex items-center justify-center"
            >
              {unreadCount > 9 ? "9+" : unreadCount}
            </motion.span>
          )}
        </Button>
      </motion.header>

      {/* Notification Panel */}
      <AnimatePresence>
        {showNotifs && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="glass-card rounded-2xl p-4 mb-4 overflow-hidden"
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground">নোটিফিকেশন</h3>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setShowNotifs(false)}>
                <X className="w-3.5 h-3.5" />
              </Button>
            </div>
            {notifications.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">কোনো নোটিফিকেশন নেই</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto scrollbar-hide">
                {notifications.slice(0, 10).map((n: any) => (
                  <div key={n.id} className={`p-2.5 rounded-xl text-xs ${n.is_read ? "bg-muted/30" : "bg-primary/5 border border-primary/10"}`}>
                    <p className="font-medium text-foreground">{n.title}</p>
                    <p className="text-muted-foreground mt-0.5">{n.message}</p>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default DashboardHeader;
