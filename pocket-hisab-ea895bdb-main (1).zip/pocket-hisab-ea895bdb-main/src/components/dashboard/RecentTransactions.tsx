import { motion } from "framer-motion";
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight, ChevronRight } from "lucide-react";
import { useTransactions } from "@/hooks/useTransactions";
import { formatDistanceToNow } from "date-fns";
import { bn } from "date-fns/locale";

const typeConfig = {
  expense: { icon: ArrowDownLeft, color: "text-destructive", bg: "bg-destructive/10", label: "খরচ" },
  income: { icon: ArrowUpRight, color: "text-success", bg: "bg-success/10", label: "আয়" },
  transfer: { icon: ArrowLeftRight, color: "text-accent", bg: "bg-accent/10", label: "ট্রান্সফার" },
};

const RecentTransactions = () => {
  const { data: transactions } = useTransactions();
  const recent = transactions?.slice(0, 6) ?? [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="glass-card rounded-2xl p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-foreground">সাম্প্রতিক লেনদেন</h3>
        {recent.length > 0 && (
          <button className="text-[11px] text-primary flex items-center gap-0.5 font-medium">
            সব দেখুন <ChevronRight className="w-3 h-3" />
          </button>
        )}
      </div>

      {recent.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-3xl mb-2">📝</p>
          <p className="text-muted-foreground text-sm font-medium">কোনো লেনদেন নেই</p>
          <p className="text-xs text-muted-foreground mt-1">AI দিয়ে বা + বাটন দিয়ে এন্ট্রি দিন</p>
        </div>
      ) : (
        <div className="space-y-1">
          {recent.map((tx, i) => {
            const config = typeConfig[tx.type];
            const Icon = config.icon;
            return (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.35 + i * 0.05 }}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-muted/30 transition-colors"
              >
                <div className={`w-9 h-9 rounded-xl ${config.bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${config.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {tx.category || tx.note || config.label}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {formatDistanceToNow(new Date(tx.created_at), { addSuffix: true, locale: bn })}
                  </p>
                </div>
                <span className={`text-sm font-mono font-bold ${tx.type === "income" ? "text-success" : config.color}`}>
                  {tx.type === "income" ? "+" : "-"}৳{tx.amount.toLocaleString("bn-BD")}
                </span>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
};

export default RecentTransactions;
