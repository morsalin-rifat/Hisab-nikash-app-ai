import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Send, Loader2, Check, X, MessageCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

interface ParsedTransaction {
  type: "expense" | "income" | "transfer";
  amount: number;
  category: string;
  wallet: string;
  to_wallet?: string;
  note?: string;
  confidence: number;
  display_summary: string;
}

interface MagicAIInputProps {
  onParsed: (data: ParsedTransaction) => void;
}

const typeLabels = {
  expense: { label: "খরচ", color: "text-destructive", bg: "bg-destructive/10" },
  income: { label: "আয়", color: "text-success", bg: "bg-success/10" },
  transfer: { label: "ট্রান্সফার", color: "text-accent", bg: "bg-accent/10" },
};

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  parsed?: ParsedTransaction;
};

const MagicAIInput = ({ onParsed }: MagicAIInputProps) => {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [chatMode, setChatMode] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [parsed, setParsed] = useState<ParsedTransaction | null>(null);
  const [streamingText, setStreamingText] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const handleParse = async () => {
    if (!input.trim() || loading) return;
    const userInput = input.trim();
    setLoading(true);
    setParsed(null);
    setInput("");

    if (chatMode) {
      const userMsg: ChatMessage = { role: "user", content: userInput };
      setMessages(prev => [...prev, userMsg]);
      setStreamingText("");

      try {
        const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-agent`;
        const resp = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content })),
          }),
        });

        if (!resp.ok || !resp.body) {
          if (resp.status === 429) { toast.error("অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন"); setLoading(false); return; }
          if (resp.status === 402) { toast.error("AI ক্রেডিট শেষ হয়ে গেছে"); setLoading(false); return; }
          throw new Error("AI error");
        }

        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullText = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          let newlineIndex: number;
          while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
            let line = buffer.slice(0, newlineIndex);
            buffer = buffer.slice(newlineIndex + 1);
            if (line.endsWith("\r")) line = line.slice(0, -1);
            if (line.startsWith(":") || line.trim() === "" || !line.startsWith("data: ")) continue;
            const jsonStr = line.slice(6).trim();
            if (jsonStr === "[DONE]") break;
            try {
              const p = JSON.parse(jsonStr);
              const content = p.choices?.[0]?.delta?.content;
              if (content) {
                fullText += content;
                setStreamingText(fullText);
              }
            } catch { /* partial */ }
          }
        }

        setMessages(prev => [...prev, { role: "assistant", content: fullText }]);
        setStreamingText("");
      } catch (err: any) {
        toast.error(err.message || "AI সমস্যা");
      } finally {
        setLoading(false);
      }
      return;
    }

    // Transaction parsing mode
    try {
      const { data, error } = await supabase.functions.invoke("parse-transaction", {
        body: { message: userInput },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setParsed(data as ParsedTransaction);
    } catch (err: any) {
      toast.error(err.message || "AI পার্স করতে পারেনি");
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = () => {
    if (parsed) {
      onParsed(parsed);
      setParsed(null);
      setInput("");
    }
  };

  return (
    <div className="space-y-3">
      {/* Mode Toggle + Input */}
      <motion.div
        className="glass-card rounded-2xl p-1.5 flex items-center gap-2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <button
          onClick={() => { setChatMode(!chatMode); setMessages([]); setParsed(null); }}
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ml-1 transition-colors ${
            chatMode ? "bg-accent/20" : "bg-primary/20"
          }`}
        >
          {chatMode ? (
            <MessageCircle className="w-4 h-4 text-accent" />
          ) : (
            <Sparkles className="w-4 h-4 text-primary" />
          )}
        </button>
        <Input
          ref={inputRef}
          placeholder={chatMode ? "AI এসিস্ট্যান্টকে জিজ্ঞাসা করুন..." : 'লিখুন: "চায়ে ২০ টাকা bKash থেকে"'}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleParse()}
          className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 text-sm text-foreground placeholder:text-muted-foreground/50"
          disabled={loading}
        />
        <Button
          size="icon"
          onClick={handleParse}
          disabled={loading || !input.trim()}
          className={`rounded-xl shrink-0 mr-1 ${chatMode ? "bg-accent/20 hover:bg-accent/30 text-accent" : "bg-primary/20 hover:bg-primary/30 text-primary"}`}
          variant="ghost"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </motion.div>

      {/* Chat Messages */}
      <AnimatePresence>
        {chatMode && messages.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="glass-card rounded-2xl p-3 max-h-60 overflow-y-auto scrollbar-hide space-y-2"
          >
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] rounded-xl px-3 py-2 text-xs ${
                  msg.role === "user"
                    ? "bg-primary/20 text-foreground"
                    : "bg-muted/50 text-foreground"
                }`}>
                  {msg.role === "assistant" ? (
                    <div className="prose prose-xs prose-invert max-w-none [&_p]:m-0 [&_p]:text-xs">
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  ) : msg.content}
                </div>
              </div>
            ))}
            {streamingText && (
              <div className="flex justify-start">
                <div className="max-w-[85%] rounded-xl px-3 py-2 text-xs bg-muted/50 text-foreground">
                  <div className="prose prose-xs prose-invert max-w-none [&_p]:m-0 [&_p]:text-xs">
                    <ReactMarkdown>{streamingText}</ReactMarkdown>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Parsed Preview */}
      <AnimatePresence>
        {parsed && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="glass-card rounded-2xl p-4 space-y-3 overflow-hidden"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${typeLabels[parsed.type].bg} ${typeLabels[parsed.type].color}`}>
                  {typeLabels[parsed.type].label}
                </div>
                <span className="text-[11px] text-muted-foreground">
                  {Math.round(parsed.confidence * 100)}% নিশ্চিত
                </span>
              </div>
              <span className="text-lg font-bold font-mono text-foreground">
                ৳{parsed.amount.toLocaleString("bn-BD")}
              </span>
            </div>

            <p className="text-sm text-foreground/80">{parsed.display_summary}</p>

            <div className="flex flex-wrap gap-1.5 text-[11px]">
              <span className="px-2 py-0.5 rounded-lg bg-muted text-muted-foreground">{parsed.category}</span>
              <span className="px-2 py-0.5 rounded-lg bg-muted text-muted-foreground">{parsed.wallet}</span>
              {parsed.to_wallet && (
                <span className="px-2 py-0.5 rounded-lg bg-muted text-muted-foreground">→ {parsed.to_wallet}</span>
              )}
            </div>

            <div className="flex gap-2 pt-1">
              <Button onClick={handleConfirm} className="flex-1 rounded-xl bg-primary text-primary-foreground py-5">
                <Check className="w-4 h-4 mr-1" /> সেভ করুন
              </Button>
              <Button onClick={() => setParsed(null)} variant="outline" className="rounded-xl border-border py-5">
                <X className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MagicAIInput;
