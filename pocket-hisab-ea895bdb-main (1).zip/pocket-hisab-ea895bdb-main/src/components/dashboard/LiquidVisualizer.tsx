import { motion } from "framer-motion";
import { useMemo } from "react";

interface LiquidVisualizerProps {
  budget: number;
  spent: number;
}

const LiquidVisualizer = ({ budget, spent }: LiquidVisualizerProps) => {
  const percentage = useMemo(() => {
    if (budget <= 0) return 100;
    const remaining = Math.max(0, budget - spent);
    return Math.min(100, (remaining / budget) * 100);
  }, [budget, spent]);

  const remaining = Math.max(0, budget - spent);
  const isLow = percentage < 25;
  const isMedium = percentage >= 25 && percentage < 50;

  const liquidColor = isLow
    ? "from-destructive/80 to-destructive/40"
    : isMedium
    ? "from-warning/80 to-warning/40"
    : "from-primary/80 to-accent/40";

  const statusText = isLow ? "সতর্কতা!" : isMedium ? "মাঝামাঝি" : "ভালো আছে";
  const statusColor = isLow ? "text-destructive" : isMedium ? "text-warning" : "text-primary";

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="glass-card rounded-2xl p-4 flex flex-col items-center"
    >
      {/* Circular Progress */}
      <div className="relative w-28 h-28 mb-3">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
          <motion.circle
            cx="50" cy="50" r="42"
            fill="none"
            stroke={isLow ? "hsl(var(--destructive))" : isMedium ? "hsl(var(--warning))" : "hsl(var(--primary))"}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={`${2 * Math.PI * 42}`}
            initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
            animate={{ strokeDashoffset: 2 * Math.PI * 42 * (1 - percentage / 100) }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            className="text-2xl font-bold text-foreground font-mono"
            key={percentage}
            initial={{ scale: 1.2, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
          >
            {Math.round(percentage)}%
          </motion.span>
          <span className={`text-[10px] font-semibold ${statusColor}`}>{statusText}</span>
        </div>
      </div>

      <div className="text-center space-y-0.5">
        <p className="text-base font-bold text-foreground font-mono">
          ৳{remaining.toLocaleString("bn-BD")}
        </p>
        <p className="text-[11px] text-muted-foreground font-medium">বাকি বাজেট</p>
      </div>
    </motion.div>
  );
};

export default LiquidVisualizer;
