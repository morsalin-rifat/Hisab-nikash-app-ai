import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWallets } from "@/hooks/useWallets";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { triggerHaptic } from "@/lib/haptics";
import SuccessAnimation from "./SuccessAnimation";

type TxType = "expense" | "income" | "transfer";

const EXPENSE_CATEGORIES = ["খাবার", "যাতায়াত", "শপিং", "বিল", "স্বাস্থ্য", "শিক্ষা", "বিনোদন", "পরিবার", "অন্যান্য"];
const INCOME_CATEGORIES = ["বেতন", "ফ্রিল্যান্স", "ব্যবসা", "উপহার", "বিনিয়োগ", "অন্যান্য"];

const categoryEmojis: Record<string, string> = {
  "খাবার": "🍽️", "যাতায়াত": "🚗", "শপিং": "🛍️", "বিল": "📄",
  "স্বাস্থ্য": "💊", "শিক্ষা": "📚", "বিনোদন": "🎮", "পরিবার": "👨‍👩‍👧‍👦", "অন্যান্য": "📦",
  "বেতন": "💰", "ফ্রিল্যান্স": "💻", "ব্যবসা": "📊", "উপহার": "🎁", "বিনিয়োগ": "📈",
};

const typeConfig = {
  expense: { label: "খরচ", icon: ArrowDownLeft, color: "bg-destructive/20 text-destructive border-destructive/30" },
  income: { label: "আয়", icon: ArrowUpRight, color: "bg-primary/20 text-primary border-primary/30" },
  transfer: { label: "ট্রান্সফার", icon: ArrowLeftRight, color: "bg-accent/20 text-accent border-accent/30" },
};

interface AddTransactionSheetProps {
  prefill?: {
    type: TxType;
    amount: number;
    category: string;
    wallet: string;
    to_wallet?: string;
    note?: string;
  } | null;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const AddTransactionSheet = ({ prefill, open: controlledOpen, onOpenChange }: AddTransactionSheetProps) => {
  const { user } = useAuth();
  const { data: wallets } = useWallets();
  const queryClient = useQueryClient();

  const [type, setType] = useState<TxType>("expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [walletId, setWalletId] = useState("");
  const [toWalletId, setToWalletId] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const isOpen = controlledOpen ?? false;
  const setIsOpen = onOpenChange ?? (() => {});

  // *** FIX: Sync prefill data when it changes ***
  useEffect(() => {
    if (prefill && wallets) {
      setType(prefill.type || "expense");
      setAmount(prefill.amount?.toString() || "");
      setCategory(prefill.category || "");
      setNote(prefill.note || "");
      // Match wallet by name
      const w = wallets.find(wl => wl.name === prefill.wallet);
      if (w) setWalletId(w.id);
      if (prefill.to_wallet) {
        const tw = wallets.find(wl => wl.name === prefill.to_wallet);
        if (tw) setToWalletId(tw.id);
      }
    } else if (!prefill) {
      setType("expense");
      setAmount("");
      setCategory("");
      setNote("");
      setWalletId("");
      setToWalletId("");
    }
  }, [prefill, wallets]);

  const categories = type === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const handleSubmit = async () => {
    if (!user || !amount || Number(amount) <= 0) {
      toast.error("সঠিক পরিমাণ দিন");
      return;
    }

    const selectedWallet = walletId || wallets?.[0]?.id;
    if (!selectedWallet) {
      toast.error("ওয়ালেট সিলেক্ট করুন");
      return;
    }

    setLoading(true);
    try {
      const txData: any = {
        user_id: user.id,
        type,
        amount: Number(amount),
        category: category || null,
        wallet_id: selectedWallet,
        note: note || null,
        source: prefill ? "ai" : "manual",
      };

      if (type === "transfer" && toWalletId) {
        txData.to_wallet_id = toWalletId;
      }

      const { error } = await supabase.from("transactions").insert(txData);
      if (error) throw error;

      // Update wallet balances
      if (type === "expense") {
        const wallet = wallets?.find(w => w.id === selectedWallet);
        if (wallet) {
          await supabase.from("wallets").update({ balance: wallet.balance - Number(amount) }).eq("id", selectedWallet);
        }
      } else if (type === "income") {
        const wallet = wallets?.find(w => w.id === selectedWallet);
        if (wallet) {
          await supabase.from("wallets").update({ balance: wallet.balance + Number(amount) }).eq("id", selectedWallet);
        }
      } else if (type === "transfer" && toWalletId) {
        const fromW = wallets?.find(w => w.id === selectedWallet);
        const toW = wallets?.find(w => w.id === toWalletId);
        if (fromW) await supabase.from("wallets").update({ balance: fromW.balance - Number(amount) }).eq("id", selectedWallet);
        if (toW) await supabase.from("wallets").update({ balance: toW.balance + Number(amount) }).eq("id", toWalletId);
      }

      triggerHaptic("heavy");

      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      queryClient.invalidateQueries({ queryKey: ["wallets"] });
      queryClient.invalidateQueries({ queryKey: ["todayExpenses"] });
      queryClient.invalidateQueries({ queryKey: ["monthlyExpenses"] });

      setShowSuccess(true);
      setIsOpen(false);
    } catch (err: any) {
      toast.error(err.message || "সমস্যা হয়েছে");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <SuccessAnimation show={showSuccess} onComplete={() => setShowSuccess(false)} message="লেনদেন সেভ হয়েছে! ✅" />

      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetContent side="bottom" className="bg-background border-t border-border rounded-t-3xl max-h-[90vh] overflow-y-auto">
          <SheetHeader className="pb-4">
            <SheetTitle className="text-foreground text-lg">নতুন লেনদেন</SheetTitle>
          </SheetHeader>

          {/* Type Selector */}
          <div className="grid grid-cols-3 gap-2 mb-5">
            {(["expense", "income", "transfer"] as TxType[]).map((t) => {
              const cfg = typeConfig[t];
              const Icon = cfg.icon;
              return (
                <motion.button
                  key={t}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setType(t)}
                  className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all ${
                    type === t ? cfg.color + " border-current" : "border-border text-muted-foreground hover:bg-muted/50"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs font-medium">{cfg.label}</span>
                </motion.button>
              );
            })}
          </div>

          {/* Amount Input */}
          <div className="mb-5">
            <Label className="text-muted-foreground text-xs mb-2 block">পরিমাণ (৳)</Label>
            <Input
              type="number"
              placeholder="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-3xl font-bold font-mono text-center h-16 rounded-xl bg-muted/50 border-border text-foreground"
            />
          </div>

          {/* Category Grid */}
          {type !== "transfer" && (
            <div className="mb-5">
              <Label className="text-muted-foreground text-xs mb-2 block">ক্যাটাগরি</Label>
              <div className="grid grid-cols-3 gap-2">
                {categories.map((cat) => (
                  <motion.button
                    key={cat}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setCategory(cat)}
                    className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      category === cat
                        ? "bg-primary/20 text-primary border border-primary/30"
                        : "bg-muted/50 text-muted-foreground border border-transparent hover:bg-muted"
                    }`}
                  >
                    <span>{categoryEmojis[cat] || "📦"}</span>
                    <span className="truncate">{cat}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Wallet Selection */}
          <div className="mb-5">
            <Label className="text-muted-foreground text-xs mb-2 block">
              {type === "transfer" ? "কোথা থেকে" : "ওয়ালেট"}
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {wallets?.map((w) => (
                <motion.button
                  key={w.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setWalletId(w.id)}
                  className={`flex flex-col items-center gap-1 px-3 py-3 rounded-xl text-xs transition-all ${
                    (walletId || wallets[0]?.id) === w.id
                      ? "bg-primary/20 text-primary border border-primary/30"
                      : "bg-muted/50 text-muted-foreground border border-transparent hover:bg-muted"
                  }`}
                >
                  <span className="font-medium">{w.name}</span>
                  <span className="font-mono text-[10px]">৳{w.balance.toLocaleString("bn-BD")}</span>
                </motion.button>
              ))}
            </div>
          </div>

          {/* To Wallet (transfer only) */}
          {type === "transfer" && (
            <div className="mb-5">
              <Label className="text-muted-foreground text-xs mb-2 block">কোথায়</Label>
              <div className="grid grid-cols-3 gap-2">
                {wallets?.filter(w => w.id !== (walletId || wallets?.[0]?.id)).map((w) => (
                  <motion.button
                    key={w.id}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setToWalletId(w.id)}
                    className={`flex flex-col items-center gap-1 px-3 py-3 rounded-xl text-xs transition-all ${
                      toWalletId === w.id
                        ? "bg-accent/20 text-accent border border-accent/30"
                        : "bg-muted/50 text-muted-foreground border border-transparent hover:bg-muted"
                    }`}
                  >
                    <span className="font-medium">{w.name}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Note */}
          <div className="mb-6">
            <Label className="text-muted-foreground text-xs mb-2 block">নোট (ঐচ্ছিক)</Label>
            <Input
              placeholder="বিস্তারিত লিখুন..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="rounded-xl bg-muted/50 border-border text-foreground"
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={loading || !amount}
            className="w-full py-6 rounded-xl bg-primary text-primary-foreground neon-glow-cyan text-base font-semibold"
          >
            {loading ? "সেভ হচ্ছে..." : "সেভ করুন"}
            <Check className="w-5 h-5 ml-2" />
          </Button>
        </SheetContent>
      </Sheet>
    </>
  );
};

export default AddTransactionSheet;
