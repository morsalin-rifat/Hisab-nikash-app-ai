import { motion } from "framer-motion";
import { TrendingDown, TrendingUp, Calendar, PiggyBank } from "lucide-react";
import { useTodayExpenses, useMonthlyExpenses } from "@/hooks/useTransactions";
import { useWallets } from "@/hooks/useWallets";
import { useUserSettings } from "@/hooks/useUserSettings";

const QuickStats = () => {
  const { data: todayExp = 0 } = useTodayExpenses();
  const { data: monthExp = 0 } = useMonthlyExpenses();
  const { data: wallets } = useWallets();
  const { data: settings } = useUserSettings();

  const totalBalance = wallets?.reduce((sum, w) => sum + w.balance, 0) ?? 0;
  const monthlyBudget = settings?.monthly_budget ?? 10000;
  const remaining = Math.max(0, monthlyBudget - monthExp);

  const stats = [
    { label: "আজকের খরচ", value: todayExp, icon: TrendingDown, gradient: "from-destructive/20 to-destructive/5", iconColor: "text-destructive" },
    { label: "মাসিক খরচ", value: monthExp, icon: Calendar, gradient: "from-warning/20 to-warning/5", iconColor: "text-warning" },
    { label: "বাকি বাজেট", value: remaining, icon: PiggyBank, gradient: "from-primary/20 to-primary/5", iconColor: "text-primary" },
    { label: "মোট সম্পদ", value: totalBalance, icon: TrendingUp, gradient: "from-success/20 to-success/5", iconColor: "text-success" },
  ];

  return (
    <div className="grid grid-cols-2 gap-2.5">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: i * 0.06 }}
          className={`glass-card rounded-2xl p-3.5 bg-gradient-to-br ${stat.gradient}`}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center justify-between mb-2">
            <stat.icon className={`w-4.5 h-4.5 ${stat.iconColor}`} />
          </div>
          <motion.p
            className="text-lg font-bold font-mono text-foreground leading-none"
            key={stat.value}
            initial={{ scale: 1.05, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
          >
            ৳{stat.value.toLocaleString("bn-BD")}
          </motion.p>
          <p className="text-[11px] text-muted-foreground mt-1 font-medium">{stat.label}</p>
        </motion.div>
      ))}
    </div>
  );
};

export default QuickStats;
