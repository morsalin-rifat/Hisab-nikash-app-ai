import { Sparkles } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border py-8 px-4">
    <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-neon-cyan" />
        <span className="font-bold text-lg">Pocket Hisab</span>
      </div>
      <p className="text-sm text-muted-foreground">
        © 2026 Pocket Hisab. আপনার টাকা, আপনার নিয়ন্ত্রণে।
      </p>
    </div>
  </footer>
);

export default Footer;
