import { motion } from "framer-motion";
import { Wallet, Brain, Shield, TrendingUp, Zap, Globe } from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "AI Agent",
    description: "বাংলা বা ইংলিশে বলুন — AI বুঝে নেবে। 'আজ চা খেয়েছি ২০ টাকা' বললেই এন্ট্রি হয়ে যাবে।",
    gradient: "from-neon-cyan to-neon-purple",
  },
  {
    icon: Wallet,
    title: "Multi-Wallet",
    description: "Cash, bKash, Bank — আলাদা আলাদা ওয়ালেটে ব্যালেন্স ট্র্যাক করুন। ট্রান্সফারও হবে চার্জসহ।",
    gradient: "from-neon-purple to-neon-pink",
  },
  {
    icon: TrendingUp,
    title: "Liquid Budget",
    description: "গ্লাস ট্যাঙ্কে পানির মতো বাজেট দেখুন। খরচ বাড়লে পানি কমে — ভিজ্যুয়ালি বুঝুন।",
    gradient: "from-neon-pink to-neon-cyan",
  },
  {
    icon: Shield,
    title: "Event Mode",
    description: "ট্যুরে যাচ্ছেন? আলাদা বাজেট দিন। মেইন বাজেটে কোনো প্রভাব পড়বে না।",
    gradient: "from-neon-cyan to-neon-purple",
  },
  {
    icon: Zap,
    title: "Smart Reports",
    description: "পাই চার্ট, বার চার্ট — ক্যাটাগরি অনুযায়ী খরচ দেখুন। ডাউনলোড ও এক্সপোর্ট করুন।",
    gradient: "from-neon-purple to-neon-pink",
  },
  {
    icon: Globe,
    title: "বাংলা + English",
    description: "পুরো অ্যাপ বাংলা ও ইংরেজি দুটোতেই কাজ করে। AI-ও দুই ভাষা বোঝে।",
    gradient: "from-neon-pink to-neon-cyan",
  },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12 } },
};

const item = {
  hidden: { opacity: 0, y: 40, scale: 0.95 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.5, ease: "easeOut" as const } },
};

const FeaturesSection = () => (
  <section id="features" className="relative py-24 px-4">
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl md:text-5xl font-bold mb-4">
          সব ফিচার <span className="text-gradient-neon">এক জায়গায়</span>
        </h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          আপনার টাকা ম্যানেজ করার জন্য যা যা দরকার — সব আছে Pocket Hisab-এ
        </p>
      </motion.div>

      <motion.div
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-50px" }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {features.map((f) => (
          <motion.div key={f.title} variants={item}>
            <div className="glass-card rounded-xl p-6 h-full hover:neon-glow-cyan transition-all duration-500 group cursor-default">
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${f.gradient} flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                <f.icon className="w-6 h-6 text-background" />
              </div>
              <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">{f.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{f.description}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  </section>
);

export default FeaturesSection;
