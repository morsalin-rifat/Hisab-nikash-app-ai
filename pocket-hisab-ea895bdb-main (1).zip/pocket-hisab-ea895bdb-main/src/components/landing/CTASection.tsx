import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CTASection = () => {
  const navigate = useNavigate();

  return (
    <section className="relative py-24 px-4">
      <div className="max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="glass-card rounded-3xl p-10 md:p-16 relative overflow-hidden"
        >
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <div className="absolute w-60 h-60 rounded-full blur-[80px] top-0 left-1/4" style={{ background: "hsl(var(--neon-cyan))" }} />
            <div className="absolute w-48 h-48 rounded-full blur-[60px] bottom-0 right-1/4" style={{ background: "hsl(var(--neon-purple))" }} />
          </div>

          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">আজই শুরু করুন</h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-lg mx-auto">
              আপনার টাকার হিসাব রাখুন — স্মার্টভাবে, AI দিয়ে। ফ্রি-তে ব্যবহার করুন।
            </p>
            <Button size="lg" onClick={() => navigate("/auth")}
              className="bg-primary text-primary-foreground neon-glow-cyan text-base px-10 py-6 rounded-xl">
              ফ্রি অ্যাকাউন্ট খুলুন
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
