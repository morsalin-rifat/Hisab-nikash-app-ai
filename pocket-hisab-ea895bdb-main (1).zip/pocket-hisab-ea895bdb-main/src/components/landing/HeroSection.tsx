import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Shield, Smartphone } from "lucide-react";
import { useNavigate } from "react-router-dom";

const HeroSection = () => {
  const navigate = useNavigate();

  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
      {/* Animated background orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute w-[500px] h-[500px] rounded-full opacity-20 blur-[120px]"
          style={{ background: "hsl(var(--neon-cyan))", top: "10%", left: "10%" }}
          animate={{ x: [0, 60, 0], y: [0, -40, 0] }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute w-[400px] h-[400px] rounded-full opacity-15 blur-[100px]"
          style={{ background: "hsl(var(--neon-purple))", bottom: "20%", right: "10%" }}
          animate={{ x: [0, -50, 0], y: [0, 50, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute w-[300px] h-[300px] rounded-full opacity-10 blur-[90px]"
          style={{ background: "hsl(var(--neon-pink))", top: "50%", left: "50%" }}
          animate={{ x: [0, 30, -20, 0], y: [0, -20, 30, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{ backgroundImage: "linear-gradient(hsl(var(--foreground)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--foreground)) 1px, transparent 1px)", backgroundSize: "60px 60px" }} />

      <div className="relative z-10 text-center max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-8 text-sm text-muted-foreground">
            <Sparkles className="w-4 h-4 text-primary" />
            AI-Powered Finance Manager
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: "hsl(120 60% 50%)" }} />
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight mb-6"
        >
          <span className="text-gradient-neon">Pocket</span>{" "}
          <span>Hisab</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          আপনার টাকার হিসাব রাখুন — AI দিয়ে। বাংলায় বলুন, AI বুঝবে।
          ওয়ালেট, বাজেট, রিপোর্ট — সব এক অ্যাপে।
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.45 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Button size="lg" onClick={() => navigate("/auth")}
            className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow-cyan text-base px-8 py-6 rounded-xl">
            শুরু করুন
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <Button variant="outline" size="lg"
            className="border-border text-foreground hover:bg-muted text-base px-8 py-6 rounded-xl"
            onClick={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}>
            ফিচার দেখুন
          </Button>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-8 flex items-center justify-center gap-6 text-xs text-muted-foreground"
        >
          <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> ১০০% নিরাপদ</span>
          <span className="flex items-center gap-1"><Smartphone className="w-3 h-3" /> PWA সাপোর্ট</span>
          <span>🇧🇩 বাংলাদেশের জন্য</span>
        </motion.div>

        {/* Floating wallet cards preview */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.65 }}
          className="mt-16 flex justify-center gap-3 sm:gap-4 flex-wrap"
        >
          {[
            { name: "Cash", emoji: "💵", amount: "৳৫,২৩০" },
            { name: "bKash", emoji: "📱", amount: "৳৩,৮৫০" },
            { name: "Bank", emoji: "🏦", amount: "৳১২,৪০০" },
          ].map((w, i) => (
            <motion.div
              key={w.name}
              className="glass-card rounded-xl px-5 py-4 min-w-[110px] sm:min-w-[130px] cursor-default"
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 4, delay: i * 0.5, repeat: Infinity, ease: "easeInOut" }}
              whileHover={{ scale: 1.05 }}
            >
              <p className="text-xs text-muted-foreground mb-1">{w.emoji} {w.name}</p>
              <p className="text-lg font-semibold font-mono">{w.amount}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
