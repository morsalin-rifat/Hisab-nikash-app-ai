import { motion } from "framer-motion";
import { MessageSquare, ArrowRight } from "lucide-react";

const aiConversation = [
  { role: "user", text: "আজ বিকাশে ২০০ টাকা পাঠাইছি রিকশায়" },
  { role: "ai", text: "বুঝেছি! ২০০ টাকা — bKash থেকে — যাতায়াত (রিকশা) ক্যাটাগরিতে এড করব?" },
  { role: "user", text: "হ্যাঁ" },
  { role: "ai", text: "✅ এন্ট্রি সেভ হয়েছে! bKash ব্যালেন্স আপডেট করা হলো।" },
];

const AIDemoSection = () => (
  <section className="relative py-24 px-4">
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-5xl font-bold mb-4">
          AI <span className="text-gradient-neon">আপনার ভাষায়</span> বোঝে
        </h2>
        <p className="text-muted-foreground text-lg">
          বাংলা, ইংলিশ, বাংলিশ — যেভাবে বলবেন, AI বুঝে নেবে
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="glass-card rounded-2xl p-6 md:p-8 neon-glow-purple"
      >
        <div className="flex items-center gap-2 mb-6">
          <MessageSquare className="w-5 h-5 text-neon-purple" />
          <span className="font-semibold">AI Agent</span>
        </div>

        <div className="space-y-4">
          {aiConversation.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: msg.role === "user" ? 20 : -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 + i * 0.15 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-md"
                    : "bg-muted text-foreground rounded-bl-md"
                }`}
              >
                {msg.text}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-border flex items-center gap-3">
          <div className="flex-1 glass-card rounded-xl px-4 py-3 text-sm text-muted-foreground">
            এখানে লিখুন বা বলুন...
          </div>
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
            <ArrowRight className="w-5 h-5 text-primary-foreground" />
          </div>
        </div>
      </motion.div>
    </div>
  </section>
);

export default AIDemoSection;
