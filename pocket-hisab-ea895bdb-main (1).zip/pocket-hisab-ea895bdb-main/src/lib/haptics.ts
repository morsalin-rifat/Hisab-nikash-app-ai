export function triggerHaptic(style: "light" | "medium" | "heavy" = "medium") {
  if (!navigator.vibrate) return;
  const patterns = { light: [10], medium: [30], heavy: [50, 30, 50] };
  navigator.vibrate(patterns[style]);
}
