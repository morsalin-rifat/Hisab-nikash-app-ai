import HeroSection from "@/components/landing/HeroSection";
import FeaturesSection from "@/components/landing/FeaturesSection";
import AIDemoSection from "@/components/landing/AIDemoSection";
import CTASection from "@/components/landing/CTASection";
import Footer from "@/components/landing/Footer";

const Landing = () => (
  <div className="min-h-screen bg-background dark">
    <HeroSection />
    <FeaturesSection />
    <AIDemoSection />
    <CTASection />
    <Footer />
  </div>
);

export default Landing;
