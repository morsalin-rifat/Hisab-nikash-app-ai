import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Sparkles, Mail, Lock, User, ArrowRight, Eye, EyeOff } from "lucide-react";

type AuthMode = "login" | "signup" | "forgot";

const Auth = () => {
  const [mode, setMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate("/dashboard");
  }, [user, navigate]);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: name },
            emailRedirectTo: window.location.origin,
          },
        });
        if (error) throw error;
        toast.success("ইমেইল ভেরিফিকেশন লিংক পাঠানো হয়েছে!");
      } else if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("সফলভাবে লগইন হয়েছে!");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে!");
      }
    } catch (err: any) {
      toast.error(err.message || "কিছু সমস্যা হয়েছে");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    const { error } = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (error) {
      toast.error("Google লগইনে সমস্যা হয়েছে");
      setLoading(false);
    }
  };

  const handleGuestLogin = async () => {
    setLoading(true);
    try {
      const guestEmail = `guest_${Date.now()}@pocket-hisab.app`;
      const guestPass = `Guest_${crypto.randomUUID().slice(0, 16)}`;
      const { error } = await supabase.auth.signUp({
        email: guestEmail,
        password: guestPass,
        options: { data: { full_name: "Guest User", is_guest: true } },
      });
      if (error) throw error;
      // Auto sign in for guest
      await supabase.auth.signInWithPassword({ email: guestEmail, password: guestPass });
      toast.success("Guest হিসেবে প্রবেশ করেছেন!");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background dark flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute w-[400px] h-[400px] rounded-full opacity-15 blur-[100px]"
          style={{ background: "hsl(var(--neon-cyan))", top: "5%", right: "10%" }}
          animate={{ x: [0, 40, 0], y: [0, -30, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute w-[300px] h-[300px] rounded-full opacity-10 blur-[80px]"
          style={{ background: "hsl(var(--neon-purple))", bottom: "10%", left: "5%" }}
          animate={{ x: [0, -30, 0], y: [0, 40, 0] }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4 cursor-pointer" onClick={() => navigate("/")}>
            <Sparkles className="w-8 h-8 text-primary" />
            <span className="text-3xl font-bold text-gradient-neon">Pocket Hisab</span>
          </div>
          <p className="text-muted-foreground">
            {mode === "login" ? "আপনার অ্যাকাউন্টে লগইন করুন" :
             mode === "signup" ? "নতুন অ্যাকাউন্ট তৈরি করুন" :
             "পাসওয়ার্ড রিসেট করুন"}
          </p>
        </div>

        <div className="glass-card rounded-2xl p-8 neon-glow-cyan">
          {/* Google Login */}
          <Button
            onClick={handleGoogleLogin}
            disabled={loading}
            variant="outline"
            className="w-full mb-4 py-6 rounded-xl border-border hover:bg-muted"
          >
            <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Google দিয়ে লগইন করুন
          </Button>

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">অথবা</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <AnimatePresence mode="wait">
            <motion.form
              key={mode}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              onSubmit={handleEmailAuth}
              className="space-y-4"
            >
              {mode === "signup" && (
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm">নাম</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input id="name" placeholder="আপনার নাম" value={name} onChange={e => setName(e.target.value)}
                      className="pl-10 py-5 rounded-xl bg-muted/50 border-border" required />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm">ইমেইল</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)}
                    className="pl-10 py-5 rounded-xl bg-muted/50 border-border" required />
                </div>
              </div>

              {mode !== "forgot" && (
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm">পাসওয়ার্ড</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input id="password" type={showPassword ? "text" : "password"} placeholder="••••••••"
                      value={password} onChange={e => setPassword(e.target.value)}
                      className="pl-10 pr-10 py-5 rounded-xl bg-muted/50 border-border" required minLength={6} />
                    <button type="button" onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}

              {mode === "login" && (
                <button type="button" onClick={() => setMode("forgot")}
                  className="text-xs text-primary hover:underline">পাসওয়ার্ড ভুলে গেছেন?</button>
              )}

              <Button type="submit" disabled={loading} className="w-full py-6 rounded-xl bg-primary text-primary-foreground neon-glow-cyan">
                {loading ? "অপেক্ষা করুন..." :
                  mode === "login" ? "লগইন করুন" :
                  mode === "signup" ? "অ্যাকাউন্ট তৈরি করুন" :
                  "রিসেট লিংক পাঠান"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </motion.form>
          </AnimatePresence>

          <div className="mt-5 space-y-3">
            {/* Guest Mode */}
            <Button variant="ghost" onClick={handleGuestLogin} disabled={loading}
              className="w-full py-5 rounded-xl text-muted-foreground hover:text-foreground border border-dashed border-border">
              👤 Guest হিসেবে ব্যবহার করুন
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              {mode === "login" ? (
                <>অ্যাকাউন্ট নেই? <button onClick={() => setMode("signup")} className="text-primary hover:underline">সাইন আপ করুন</button></>
              ) : mode === "signup" ? (
                <>অ্যাকাউন্ট আছে? <button onClick={() => setMode("login")} className="text-primary hover:underline">লগইন করুন</button></>
              ) : (
                <button onClick={() => setMode("login")} className="text-primary hover:underline">লগইনে ফিরে যান</button>
              )}
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Auth;
