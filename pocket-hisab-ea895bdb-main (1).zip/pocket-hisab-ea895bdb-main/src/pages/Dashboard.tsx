import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import LiquidVisualizer from "@/components/dashboard/LiquidVisualizer";
import WalletStacks from "@/components/dashboard/WalletStacks";
import QuickStats from "@/components/dashboard/QuickStats";
import RecentTransactions from "@/components/dashboard/RecentTransactions";
import MagicAIInput from "@/components/dashboard/MagicAIInput";
import AddTransactionSheet from "@/components/dashboard/AddTransactionSheet";
import BottomNav from "@/components/dashboard/BottomNav";
import SavingsGoals from "@/components/dashboard/SavingsGoals";
import { useUserSettings } from "@/hooks/useUserSettings";
import { useMonthlyExpenses } from "@/hooks/useTransactions";
import Stats from "@/pages/Stats";
import Events from "@/pages/Events";
import Settings from "@/pages/Settings";

const Dashboard = () => {
  const { data: settings } = useUserSettings();
  const { data: monthlyExp = 0 } = useMonthlyExpenses();
  const budget = settings?.monthly_budget ?? 10000;

  const [activeTab, setActiveTab] = useState("home");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [prefill, setPrefill] = useState<any>(null);

  const handleAIParsed = useCallback((data: any) => {
    setPrefill(data);
    setSheetOpen(true);
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case "stats":
        return <Stats />;
      case "wallets":
        return <Events />;
      case "settings":
        return <Settings />;
      default:
        return (
          <>
            {/* Magic AI Input */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="mb-5"
            >
              <MagicAIInput onParsed={handleAIParsed} />
            </motion.div>

            {/* Budget + Wallets */}
            <div className="grid grid-cols-[1fr_1.5fr] gap-3 mb-5">
              <LiquidVisualizer budget={budget} spent={monthlyExp} />
              <div className="flex flex-col gap-3">
                <WalletStacks />
                <SavingsGoals />
              </div>
            </div>

            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="mb-5"
            >
              <QuickStats />
            </motion.div>

            {/* Recent Transactions */}
            <RecentTransactions />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background dark">
      <div className="max-w-lg mx-auto p-4 pb-24">
        <DashboardHeader />
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </div>

      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onAddClick={() => {
          setPrefill(null);
          setSheetOpen(true);
        }}
      />

      <AddTransactionSheet
        prefill={prefill}
        open={sheetOpen}
        onOpenChange={setSheetOpen}
      />
    </div>
  );
};

export default Dashboard;
