import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Calendar, Target, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { triggerHaptic } from "@/lib/haptics";
import type { Tables } from "@/integrations/supabase/types";

type Event = Tables<"events">;

const Events = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [name, setName] = useState("");
  const [budget, setBudget] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: events = [] } = useQuery({
    queryKey: ["events", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("events")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Event[];
    },
    enabled: !!user,
  });

  const handleCreate = async () => {
    if (!user || !name.trim() || !budget) return;
    setLoading(true);
    try {
      const { error } = await supabase.from("events").insert({
        user_id: user.id,
        name: name.trim(),
        budget: Number(budget),
      });
      if (error) throw error;
      triggerHaptic("medium");
      toast.success("ইভেন্ট তৈরি হয়েছে! 🎉");
      queryClient.invalidateQueries({ queryKey: ["events"] });
      setName("");
      setBudget("");
      setSheetOpen(false);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    triggerHaptic("light");
    queryClient.invalidateQueries({ queryKey: ["events"] });
    toast.success("ইভেন্ট ডিলিট হয়েছে");
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">ইভেন্ট ও ট্রিপ</h2>
        <Button size="sm" onClick={() => setSheetOpen(true)} className="rounded-xl h-8 text-xs gap-1">
          <Plus className="w-3.5 h-3.5" /> নতুন
        </Button>
      </div>

      {events.length === 0 ? (
        <div className="glass-card rounded-2xl p-8 text-center">
          <Calendar className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-50" />
          <p className="text-sm text-muted-foreground">কোনো ইভেন্ট নেই</p>
          <p className="text-xs text-muted-foreground/60 mt-1">নতুন ট্রিপ বা ইভেন্ট তৈরি করুন</p>
        </div>
      ) : (
        <div className="space-y-3">
          {events.map((event, i) => {
            const pct = event.budget > 0 ? Math.min(100, (event.spent / event.budget) * 100) : 0;
            const remaining = Math.max(0, event.budget - event.spent);
            const isOver = event.spent > event.budget;
            return (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="glass-card rounded-2xl p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-accent/20 flex items-center justify-center">
                      <Target className="w-4 h-4 text-accent" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">{event.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        বাজেট: ৳{event.budget.toLocaleString("bn-BD")}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={() => handleDelete(event.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">
                      খরচ: ৳{event.spent.toLocaleString("bn-BD")}
                    </span>
                    <span className={isOver ? "text-destructive font-semibold" : "text-primary"}>
                      {isOver ? "ওভার!" : `বাকি: ৳${remaining.toLocaleString("bn-BD")}`}
                    </span>
                  </div>
                  <Progress value={pct} className="h-2" />
                  <p className="text-[10px] text-right text-muted-foreground">{Math.round(pct)}%</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent side="bottom" className="bg-background border-t border-border rounded-t-3xl">
          <SheetHeader><SheetTitle className="text-foreground">নতুন ইভেন্ট</SheetTitle></SheetHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label className="text-xs text-muted-foreground">ইভেন্টের নাম</Label>
              <Input placeholder="যেমন: কক্সবাজার ট্রিপ" value={name} onChange={e => setName(e.target.value)}
                className="rounded-xl bg-muted/50 border-border mt-1" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">বাজেট (৳)</Label>
              <Input type="number" placeholder="10000" value={budget} onChange={e => setBudget(e.target.value)}
                className="rounded-xl bg-muted/50 border-border mt-1 font-mono" />
            </div>
            <Button onClick={handleCreate} disabled={loading || !name.trim() || !budget}
              className="w-full py-5 rounded-xl">
              {loading ? "তৈরি হচ্ছে..." : "তৈরি করুন"}
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </motion.div>
  );
};

export default Events;
