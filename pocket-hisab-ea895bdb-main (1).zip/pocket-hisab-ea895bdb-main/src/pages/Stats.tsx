import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { useTransactions } from "@/hooks/useTransactions";
import { useWallets } from "@/hooks/useWallets";
import { Calendar, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";

type DateRange = "this_month" | "last_month" | "3_months";

const COLORS = [
  "hsl(190, 95%, 50%)", "hsl(270, 60%, 60%)", "hsl(330, 85%, 60%)",
  "hsl(45, 90%, 55%)", "hsl(140, 70%, 45%)", "hsl(0, 80%, 60%)",
  "hsl(200, 80%, 50%)", "hsl(30, 90%, 55%)", "hsl(160, 60%, 50%)",
];

const Stats = () => {
  const { data: transactions = [] } = useTransactions();
  const { data: wallets = [] } = useWallets();
  const [range, setRange] = useState<DateRange>("this_month");

  const filtered = useMemo(() => {
    const now = new Date();
    let start: Date;
    if (range === "this_month") {
      start = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (range === "last_month") {
      start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    } else {
      start = new Date(now.getFullYear(), now.getMonth() - 3, 1);
    }
    return transactions.filter(t => new Date(t.created_at) >= start);
  }, [transactions, range]);

  const expenses = filtered.filter(t => t.type === "expense");

  // Category pie data
  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};
    expenses.forEach(t => {
      const cat = t.category || "অন্যান্য";
      map[cat] = (map[cat] || 0) + t.amount;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [expenses]);

  // Daily bar data
  const dailyData = useMemo(() => {
    const map: Record<string, number> = {};
    expenses.forEach(t => {
      const day = new Date(t.created_at).getDate().toString();
      map[day] = (map[day] || 0) + t.amount;
    });
    return Object.entries(map).map(([day, amount]) => ({ day, amount })).sort((a, b) => +a.day - +b.day);
  }, [expenses]);

  const totalExp = expenses.reduce((s, t) => s + t.amount, 0);

  const ranges: { key: DateRange; label: string }[] = [
    { key: "this_month", label: "এই মাস" },
    { key: "last_month", label: "গত মাস" },
    { key: "3_months", label: "৩ মাস" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-5"
    >
      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter className="w-4 h-4 text-muted-foreground" />
        {ranges.map(r => (
          <Button
            key={r.key}
            size="sm"
            variant={range === r.key ? "default" : "outline"}
            onClick={() => setRange(r.key)}
            className="rounded-xl text-xs h-8"
          >
            {r.label}
          </Button>
        ))}
      </div>

      {/* Total */}
      <div className="glass-card rounded-2xl p-4 text-center">
        <p className="text-xs text-muted-foreground">মোট খরচ</p>
        <p className="text-2xl font-bold font-mono text-destructive">৳{totalExp.toLocaleString("bn-BD")}</p>
      </div>

      {/* Daily Bar Chart */}
      <div className="glass-card rounded-2xl p-4">
        <h3 className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wider">দৈনিক খরচ</h3>
        {dailyData.length > 0 ? (
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={dailyData}>
              <XAxis dataKey="day" tick={{ fontSize: 10, fill: "hsl(215, 20%, 60%)" }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ background: "hsl(225, 25%, 10%)", border: "1px solid hsl(225, 20%, 20%)", borderRadius: 12, fontSize: 12 }}
                labelStyle={{ color: "hsl(210, 40%, 98%)" }}
                formatter={(v: number) => [`৳${v.toLocaleString("bn-BD")}`, "খরচ"]}
              />
              <Bar dataKey="amount" fill="hsl(190, 95%, 50%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-center text-muted-foreground text-sm py-8">ডাটা নেই</p>
        )}
      </div>

      {/* Category Pie */}
      <div className="glass-card rounded-2xl p-4">
        <h3 className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wider">ক্যাটাগরি অনুযায়ী</h3>
        {categoryData.length > 0 ? (
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" innerRadius={35} outerRadius={60} dataKey="value" strokeWidth={0}>
                  {categoryData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-1.5">
              {categoryData.slice(0, 5).map((cat, i) => (
                <div key={cat.name} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-xs text-foreground flex-1 truncate">{cat.name}</span>
                  <span className="text-xs font-mono text-muted-foreground">৳{cat.value.toLocaleString("bn-BD")}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-center text-muted-foreground text-sm py-8">ডাটা নেই</p>
        )}
      </div>

      {/* Wallet Breakdown */}
      <div className="glass-card rounded-2xl p-4">
        <h3 className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wider">ওয়ালেট ব্যালেন্স</h3>
        <div className="space-y-3">
          {wallets.map((w, i) => {
            const total = wallets.reduce((s, wl) => s + Math.abs(wl.balance), 0) || 1;
            const pct = Math.abs(w.balance) / total * 100;
            return (
              <div key={w.id} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-foreground font-medium">{w.name}</span>
                  <span className="font-mono text-muted-foreground">৳{w.balance.toLocaleString("bn-BD")}</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.8, delay: i * 0.1 }}
                    className="h-full rounded-full"
                    style={{ background: COLORS[i % COLORS.length] }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
};

export default Stats;
