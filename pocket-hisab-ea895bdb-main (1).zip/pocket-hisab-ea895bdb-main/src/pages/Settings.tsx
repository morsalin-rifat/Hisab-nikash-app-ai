import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { User, DollarSign, LogOut, Save, LinkIcon, Download, Upload, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useUserSettings } from "@/hooks/useUserSettings";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { triggerHaptic } from "@/lib/haptics";
import type { Tables } from "@/integrations/supabase/types";

type Profile = Tables<"profiles">;

const Settings = () => {
  const { user, signOut } = useAuth();
  const { data: settings } = useUserSettings();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isGuest = user?.user_metadata?.is_guest === true;

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase.from("profiles").select("*").eq("user_id", user.id).maybeSingle();
      return data as Profile | null;
    },
    enabled: !!user,
  });

  const [displayName, setDisplayName] = useState("");
  const [monthlyBudget, setMonthlyBudget] = useState("");
  const [saving, setSaving] = useState(false);
  const [linkEmail, setLinkEmail] = useState("");
  const [linkPassword, setLinkPassword] = useState("");
  const [linking, setLinking] = useState(false);

  useEffect(() => {
    if (profile) setDisplayName(profile.display_name || "");
    if (settings) setMonthlyBudget(settings.monthly_budget?.toString() || "0");
  }, [profile, settings]);

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);
    try {
      await supabase.from("profiles").update({ display_name: displayName }).eq("user_id", user.id);
      if (settings) {
        await supabase.from("user_settings").update({ monthly_budget: Number(monthlyBudget) || 0 }).eq("user_id", user.id);
      } else {
        await supabase.from("user_settings").insert({ user_id: user.id, monthly_budget: Number(monthlyBudget) || 0 });
      }
      triggerHaptic("medium");
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      queryClient.invalidateQueries({ queryKey: ["userSettings"] });
      toast.success("সেটিংস সেভ হয়েছে! ✅");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleLinkAccount = async () => {
    if (!linkEmail || !linkPassword) return;
    setLinking(true);
    try {
      const { error } = await supabase.auth.updateUser({ email: linkEmail, password: linkPassword });
      if (error) throw error;
      triggerHaptic("heavy");
      toast.success("অ্যাকাউন্ট লিংক হয়েছে! 🎉");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLinking(false);
    }
  };

  const handleExportCSV = async () => {
    if (!user) return;
    const { data } = await supabase.from("transactions").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
    if (!data || data.length === 0) { toast.error("কোনো ডাটা নেই"); return; }

    const headers = ["তারিখ", "ধরন", "পরিমাণ", "ক্যাটাগরি", "ওয়ালেট", "নোট"];
    const rows = data.map(t => [
      new Date(t.created_at).toLocaleDateString("bn-BD"),
      t.type === "expense" ? "খরচ" : t.type === "income" ? "আয়" : "ট্রান্সফার",
      t.amount,
      t.category || "",
      t.wallet_id || "",
      t.note || "",
    ]);
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `pocket-hisab-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    triggerHaptic("medium");
    toast.success("CSV ডাউনলোড হয়েছে! 📁");
  };

  const handleImportCSV = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    const text = await file.text();
    const lines = text.split("\n").filter(l => l.trim());
    if (lines.length <= 1) { toast.error("ফাইল খালি"); return; }

    try {
      const rows = lines.slice(1).map(line => {
        const cols = line.split(",");
        const typeMap: Record<string, string> = { "খরচ": "expense", "আয়": "income", "ট্রান্সফার": "transfer" };
        return {
          user_id: user.id,
          type: (typeMap[cols[1]?.trim()] || "expense") as "expense" | "income" | "transfer",
          amount: Number(cols[2]) || 0,
          category: cols[3]?.trim() || null,
          note: cols[5]?.trim() || null,
          source: "import",
        };
      }).filter(r => r.amount > 0);

      if (rows.length === 0) { toast.error("কোনো ভ্যালিড ডাটা নেই"); return; }

      const { error } = await supabase.from("transactions").insert(rows);
      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      triggerHaptic("heavy");
      toast.success(`${rows.length}টি লেনদেন ইম্পোর্ট হয়েছে! ✅`);
    } catch (err: any) {
      toast.error(err.message);
    }
    e.target.value = "";
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      {/* Guest Linking */}
      {isGuest && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-2xl p-4 space-y-3 border border-accent/30">
          <div className="flex items-center gap-2">
            <LinkIcon className="w-4 h-4 text-accent" />
            <h3 className="text-sm font-semibold text-foreground">অ্যাকাউন্ট লিংক করুন</h3>
          </div>
          <p className="text-xs text-muted-foreground">
            Guest হিসেবে আছেন। লিংক করলে ডাটা সুরক্ষিত থাকবে।
          </p>
          <div className="space-y-2">
            <Input placeholder="ইমেইল" type="email" value={linkEmail} onChange={e => setLinkEmail(e.target.value)}
              className="rounded-xl bg-muted/50 border-border text-sm" />
            <Input placeholder="পাসওয়ার্ড" type="password" value={linkPassword} onChange={e => setLinkPassword(e.target.value)}
              className="rounded-xl bg-muted/50 border-border text-sm" minLength={6} />
            <Button onClick={handleLinkAccount} disabled={linking || !linkEmail || !linkPassword} className="w-full rounded-xl text-sm">
              {linking ? "লিংক হচ্ছে..." : "অ্যাকাউন্ট লিংক করুন"}
            </Button>
          </div>
        </motion.div>
      )}

      {/* Profile */}
      <div className="glass-card rounded-2xl p-4 space-y-3">
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">প্রোফাইল</h3>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">নাম</Label>
          <Input value={displayName} onChange={e => setDisplayName(e.target.value)}
            className="rounded-xl bg-muted/50 border-border mt-1" />
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">ইমেইল</Label>
          <Input value={user?.email || ""} disabled className="rounded-xl bg-muted/30 border-border mt-1 text-muted-foreground" />
        </div>
      </div>

      {/* Budget */}
      <div className="glass-card rounded-2xl p-4 space-y-3">
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">মাসিক বাজেট</h3>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">বাজেট (৳)</Label>
          <Input type="number" value={monthlyBudget} onChange={e => setMonthlyBudget(e.target.value)}
            className="rounded-xl bg-muted/50 border-border mt-1 font-mono" />
        </div>
      </div>

      {/* Save */}
      <Button onClick={handleSaveProfile} disabled={saving} className="w-full py-5 rounded-xl gap-2">
        <Save className="w-4 h-4" />
        {saving ? "সেভ হচ্ছে..." : "সেভ করুন"}
      </Button>

      {/* Data Export/Import */}
      <div className="glass-card rounded-2xl p-4 space-y-3">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">ডাটা ম্যানেজমেন্ট</h3>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={handleExportCSV} className="rounded-xl text-xs gap-1.5 py-4">
            <Download className="w-3.5 h-3.5" /> CSV এক্সপোর্ট
          </Button>
          <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="rounded-xl text-xs gap-1.5 py-4">
            <Upload className="w-3.5 h-3.5" /> CSV ইম্পোর্ট
          </Button>
        </div>
        <input ref={fileInputRef} type="file" accept=".csv" onChange={handleImportCSV} className="hidden" />
      </div>

      {/* Logout */}
      <Button variant="outline" onClick={handleSignOut}
        className="w-full py-5 rounded-xl border-destructive/30 text-destructive hover:bg-destructive/10 gap-2">
        <LogOut className="w-4 h-4" />
        লগ আউট
      </Button>
    </motion.div>
  );
};

export default Settings;
