import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Lock, Sparkles } from "lucide-react";

const ResetPassword = () => {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const hash = window.location.hash;
    if (!hash.includes("type=recovery")) {
      toast.error("Invalid reset link");
      navigate("/auth");
    }
  }, [navigate]);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
      toast.error(error.message);
    } else {
      toast.success("পাসওয়ার্ড আপডেট হয়েছে!");
      navigate("/dashboard");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background dark flex items-center justify-center px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <Sparkles className="w-8 h-8 text-primary mx-auto mb-2" />
          <h1 className="text-2xl font-bold">নতুন পাসওয়ার্ড সেট করুন</h1>
        </div>
        <form onSubmit={handleReset} className="glass-card rounded-2xl p-8 space-y-4">
          <div className="space-y-2">
            <Label>নতুন পাসওয়ার্ড</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input type="password" value={password} onChange={e => setPassword(e.target.value)}
                className="pl-10 py-5 rounded-xl" placeholder="নতুন পাসওয়ার্ড" required minLength={6} />
            </div>
          </div>
          <Button type="submit" disabled={loading} className="w-full py-6 rounded-xl bg-primary neon-glow-cyan">
            {loading ? "অপেক্ষা করুন..." : "পাসওয়ার্ড আপডেট করুন"}
          </Button>
        </form>
      </motion.div>
    </div>
  );
};

export default ResetPassword;
